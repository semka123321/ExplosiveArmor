package com.yourname.explosivearmor;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class SoundRegistry {
    public static final DeferredRegister<SoundEvent> SOUNDS = 
        DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, ExplosiveArmorMod.MOD_ID);

    public static final RegistryObject<SoundEvent> DETONATE_SOUND = 
        SOUNDS.register("detonate", 
            () -> SoundEvent.createVariableRangeEvent(
                new ResourceLocation(ExplosiveArmorMod.MOD_ID, "detonate")
            )
        );

    public static final RegistryObject<SoundEvent> PRIMED_SOUND = 
        SOUNDS.register("primed", 
            () -> SoundEvent.createVariableRangeEvent(
                new ResourceLocation(ExplosiveArmorMod.MOD_ID, "primed")
            )
        );

    public static final RegistryObject<SoundEvent> EXPLOSION_SOUND = 
        SOUNDS.register("explosion", 
            () -> SoundEvent.createVariableRangeEvent(
                new ResourceLocation(ExplosiveArmorMod.MOD_ID, "explosion")
            )
        );
}
