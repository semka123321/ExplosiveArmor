package com.yourname.explosivearmor;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = ExplosiveArmorMod.MOD_ID, value = Dist.CLIENT)
public class KeyInputHandler {
    
    public static final String KEY_CATEGORY = "key.category.explosivearmor";
    public static final String KEY_DETONATE = "key.explosivearmor.detonate";
    
    public static final KeyMapping detonateKey = new KeyMapping(
        KEY_DETONATE,
        InputConstants.Type.KEYSYM,
        GLFW.GLFW_KEY_N,
        KEY_CATEGORY
    );

    @SubscribeEvent
    public static void onKeyInput(InputEvent.Key event) {
        if (detonateKey.consumeClick()) {
            Minecraft mc = Minecraft.getInstance();
            Player player = mc.player;
            
            if (player != null) {
                ItemStack chestplate = player.getItemBySlot(EquipmentSlot.CHEST);
                
                if (chestplate.getItem() instanceof ExplosiveChestplateItem) {
                    detonate(player);
                }
            }
        }
    }

    private static void detonate(Player player) {
        Level level = player.level();
        
        // Воспроизводим звуки взрыва
        level.playSound(player, player.blockPosition(), SoundRegistry.PRIMED_SOUND.get(), SoundSource.PLAYERS, 1.0F, 1.0F);
        level.playSound(player, player.blockPosition(), SoundRegistry.DETONATE_SOUND.get(), SoundSource.PLAYERS, 1.0F, 1.0F);
        
        // Локальный клиентский взрыв (сила 8.0)
        level.explode(player, player.getX(), player.getY(), player.getZ(), 8.0F, Level.ExplosionInteraction.TNT);
        
        // Очищаем слот брони и наносим визуальный урон
        player.setItemSlot(EquipmentSlot.CHEST, ItemStack.EMPTY);
        player.hurt(player.damageSources().explosion(null), 4.0F);
    }

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(detonateKey);
    }
}
