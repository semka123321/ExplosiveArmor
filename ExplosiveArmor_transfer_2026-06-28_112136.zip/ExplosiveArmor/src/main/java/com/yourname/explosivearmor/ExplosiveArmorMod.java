package com.yourname.explosivearmor;

import com.yourname.explosivearmor.client.model.CustomArmorModel;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.client.event.EntityRenderersEvent;

@Mod(ExplosiveArmorMod.MOD_ID)
public class ExplosiveArmorMod {
    public static final String MOD_ID = "explosivearmor";
    
    // Регистрация предметов
    public static final DeferredRegister<Item> ITEMS = 
        DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);

    public static final RegistryObject<Item> EXPLOSIVE_CHESTPLATE = 
        ITEMS.register("explosive_chestplate", ExplosiveChestplateItem::new);

    public ExplosiveArmorMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        
        // Привязываем регистраторы
        ITEMS.register(modEventBus);
        SoundRegistry.SOUNDS.register(modEventBus);
        
        // Слушаем загрузку моделей
        modEventBus.addListener(this::registerLayers);
        
        // Включаем обработчик кнопки напрямую
        MinecraftForge.EVENT_BUS.register(new KeyInputHandler());
    }

    private void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(
            CustomArmorModel.LAYER_LOCATION, 
            CustomArmorModel::createBodyLayer
        );
    }
}

